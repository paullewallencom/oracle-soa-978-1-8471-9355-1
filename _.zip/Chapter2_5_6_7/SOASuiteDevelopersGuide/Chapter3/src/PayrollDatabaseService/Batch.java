package PayrollDatabaseService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Batch {

    /**Map payrollitemCollection <-> PayrollDatabaseService.Payrollitem
     * @associates <{PayrollDatabaseService.Payrollitem}>
     */
    private List payrollitemCollection;
    private String id;
    private Date batchdate;


}
