package PayrollDatabaseService;

import java.util.ArrayList;
import java.util.List;

public class Employee {

    /**Map payrollitemCollection <-> PayrollDatabaseService.Payrollitem
     * @associates <{PayrollDatabaseService.Payrollitem}>
     */
    private List payrollitemCollection;
    private String id;
    private String firstname;
    private String lastname;


}
