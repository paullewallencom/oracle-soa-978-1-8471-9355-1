Read Me
=======
This directory contains the following:

1. StockService.xsd - This is the schema required when creating the StockQuote and StockOrder processes.
2. XigniteQuotes.wsdl - WDSL for Xignites Stock Quote Service
3. CurrencyConvertor.wsdl - WSDL for webserviceX.NET's exchange rate service

Which are required to build the examples in Chapter 05.