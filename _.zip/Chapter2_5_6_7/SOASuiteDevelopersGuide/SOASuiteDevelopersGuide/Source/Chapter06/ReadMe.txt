Read Me
=======
This directory contains the following:

1. LeaveRequest.xsd - This is the schema required when creating the LeaveApproval process.


Which is required to build the examples in Chapter 06.