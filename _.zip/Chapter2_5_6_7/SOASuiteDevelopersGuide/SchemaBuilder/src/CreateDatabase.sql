@CreateUsers.sql
connect soabook/soabook
@CreateSoaBookSchema.sql