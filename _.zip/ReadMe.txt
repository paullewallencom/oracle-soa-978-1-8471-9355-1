********************************************
Oracle SOA Suite Developer's Guide
********************************************

Chapter 1 - No Code
Chapter 2 - Code Present
Chapter 3 - No Code
Chapter 4 - No Code
Chapter 5 - Code Present
Chapter 6 - Code Present
Chapter 7 - Code Present
Chapter 8 - No Code
Chapter 9 - Refer oBay
Chapter 10 - Refer oBay
Chapter 11 - Refer oBay
Chapter 12 - Refer oBay
Chapter 13 - Refer oBay
Chapter 14 - Refer oBay
Chapter 15 - Refer oBay
Chapter 16 - Refer oBay
Chapter 17 - No Code 
Chapter 18 - No Code  
Chapter 19 - No Code
Chapter 20 - No COde


This folder contains text files that contain the codes for the respective chapters.